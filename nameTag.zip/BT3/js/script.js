function hienThiTen() {
  var hoTen = document.getElementById("hoten").value;
  alert("Tên: " + hoTen);
}
function hienThiTuoi() {
  var tuoi = document.getElementById("tuoi").value;
  alert("Tuổi: " + tuoi);
}
function hienThiChieuCao() {
  var chieucao = document.getElementById("chieucao").value;
  alert("Chiều Cao: " + chieucao);
}
function getInfo() {
   var hoTen = document.getElementById("hoten").value;
   var tuoi = document.getElementById("tuoi").value;
   var chieucao = document.getElementById("chieucao").value;
   alert("Thông tin vừa lưu "+ "\nHọ tên: "+hoTen+"\nTuổi: "+tuoi+"\nChiều Cao: "+ chieucao);
}
  